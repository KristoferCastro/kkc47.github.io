/*
 * This class is a subclass of cell extending in functionality that it has the condition to be damaged
 * or not.
 * 
 */

package ca.cmpt213.as2;

public class TankCell extends Cell {

	private boolean isDamaged;
	
	public TankCell(Coordinate c){
		this.coordinate = c;
	}
	
	public boolean isDamaged(){
		return isDamaged;
		
	}
	
	public void setIsDamaged(boolean isDamaged){
		this.isDamaged = isDamaged;
	}

}
