/*
 * This is the main entry point of the game that includes the main gameplay logic and game
 * initiatization (num rows, cols, num tanks, fortress structural strength)
 * 
 */
package ca.cmpt213.as2;

import java.util.Scanner;

public class GameSystem {
	public static BattleField battlefield; 
	public static Fortress fortress;
	private static Player player;
	private static Cpu cpu;
	public static int numRows;
	public static int numCol;
	public static int numTanks;
	private static int fortressStructure=1500;
	
	
	public static void main(String[] args) {

		initializeGame();
		
		while(true){
			player.startTurn();
			//check for win/lose
			if (player.isWin()){
				System.out.println(" I WON!");
				break;
			}else{
				// Do the fortress being attacked.
				
				cpu.startTurn();
				if (player.isLose()){
					System.out.println("Sorry, your fortress has been smashed! ");
					
					System.out.println("Here are the user and system boards.  Check to see where you missed!");
					GameSystem.battlefield.showUserBoard();
					GameSystem.battlefield.showSystemBoard();
					GameSystem.battlefield.showCombinedBoard();
					System.out.println("End of the game.");
					break;
				}
			}
		}
		
		//gameStatistics();
	}
	
	public static void initializeGame(){
		
		player = new Player();
		cpu = new Cpu();
		
		Scanner scan = new Scanner(System.in);
		System.out.println("-------------------------------------------");
		System.out.println("Welcome to FORTRESS DEFENSE!");
		System.out.println("by Kristofer Ken Castro and Sejal Rathee");
		System.out.println("-------------------------------------------");
		
		System.out.println("SETTING UP THE GAME: ");
		System.out.println("Enter number of rows/columns (NxN) in the game board : ");
		numRows = scan.nextInt();
		numCol = numRows;
		System.out.println("Enter number of tanks : ");
		numTanks = scan.nextInt();
		
		System.out.println("Starting the game:");
		System.out.println("_________________________________________");
		
		generateField();
	}
	
	private static void generateField(){
		
		fortress = new Fortress(fortressStructure);
		
		battlefield = new BattleField(numRows, numCol, numTanks);
		battlefield.showUserBoard(); 
	}

}
