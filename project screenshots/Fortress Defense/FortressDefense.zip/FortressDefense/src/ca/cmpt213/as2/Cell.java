package ca.cmpt213.as2;

public class Cell {

	public Coordinate coordinate;

}
