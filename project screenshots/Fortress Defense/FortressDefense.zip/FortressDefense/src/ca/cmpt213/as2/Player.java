/*
 * This clas handles the gameplay logic of behaviors for the player of the game.
 * Staring turn and using the fortress to fire it's guns is this class main functionality.
 * 
 */

package ca.cmpt213.as2;

import java.util.Scanner;

public class Player {
	
	public void startTurn(){
		
		boolean isValidTurn = false;
		System.out.println("Fortress Structure Left: " + GameSystem.fortress.getStructuralStrength());
	    
		Scanner in = new Scanner(System.in);
	    String location;
	    System.out.println("enter a location: ");
	    location = in.nextLine();
	    
	    char row;
	    String columnString = null;
	    char upperCaseRow = 0;
	    int column = 0;
	    
	    if (location.length() >= 2){
		    row = location.charAt(0);
	        upperCaseRow = Character.toUpperCase(row);
		    
	        columnString = "";
		    for(int i = 1; i < location.length(); i++){
		    	columnString += location.charAt(i);
		    }
		    
		    if (isColumnValid(location)){
		    	column = Integer.parseInt(columnString);
		    }
	    }
	    
        while(!isValidTurn){
            if( location.length() < 2 || !isAllNumber(columnString) || column > GameSystem.numCol || (!isRowValid(location))){
                System.out.println("Invalid location. Please enter valid location like D10: ");
                location = in.nextLine();
                
                if (location.length() >= 2){
        		    row = location.charAt(0);
        	        upperCaseRow = Character.toUpperCase(row);
        		    
        	        columnString = "";
        		    for(int i = 1; i < location.length(); i++){
        		    	columnString += location.charAt(i);
        		    }
        		    
        		    if (isColumnValid(location)){
        		    	column = Integer.parseInt(columnString);
        		    }
        	    }
                
                isValidTurn = false;
            }
            else {
                isValidTurn = true;
                Coordinate tankPosition = new Coordinate(upperCaseRow, column);
                fireGun(tankPosition);
            }
		}
	    
	    
	}
	
	private boolean isColumnValid(String location){
	    String columnString = "";
		for(int i = 1; i < location.length(); i++){
	    	columnString += location.charAt(i);
	    }
		return isAllNumber(columnString);
	}
	private boolean isAllNumber(String str){
		for(char c : str.toCharArray()){
			if (c < '1' || c > '9')
				return false;
		}
		return true;
	}
    
    private boolean isRowValid(String location){
		char row = location.charAt(0);
		char upperCaseRow = Character.toUpperCase(row);
		int rowValue = (int)upperCaseRow;
	    int gameRow = (int)(GameSystem.numRows + 'A');
	    if(rowValue<gameRow){
	    	return true;
	    }
	    return false;
	}
	
	public  boolean isLose(){
		if(GameSystem.fortress.getStructuralStrength() <= 0)
		{
			return true;
		}
		return false;
	}
	
	public boolean isWin(){
		// Let's get all the tanks in the field
		if (GameSystem.battlefield.numberOfTanksDestroyed() == GameSystem.numTanks)
			return true;
		return false;
	}
	
	private void fireGun(Coordinate tankPosition){
		GameSystem.fortress.fireGun(tankPosition);
	}	

}
