/*
 * This handles behaviors of Fortress.  Manages its structural strength and gun firing.
 * 
 */

package ca.cmpt213.as2;

import java.util.Scanner;

public class Fortress {
	
	private static int structuralStrength ;
	//private static BattleField battlefield;
	

	/*
	 * Testing the functions, remove this main method later
	 */
	public static void main(String[] args) {
		/*setStructuralStrength(1500);
		System.out.println("structural strength is: " + getStructuralStrength());*/
	}
	
	public Fortress(int fortressStructure) {
		// TODO Auto-generated constructor stub
		structuralStrength = fortressStructure;
	}

	public int getStructuralStrength() {
		return structuralStrength;
	}

	public void setStructuralStrength(int structuralStrength) {
		Fortress.structuralStrength = structuralStrength;
	}
	
	public void fireGun(Coordinate tankPosition){
		GameSystem.battlefield.markCells(tankPosition);
		GameSystem.battlefield.showUserBoard();
	}
	
	public void showBattlefield(BattleField battlefield){
		battlefield.showSystemBoard();
		
	}


}
