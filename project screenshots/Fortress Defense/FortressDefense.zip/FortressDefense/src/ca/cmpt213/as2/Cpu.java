/*
 * This class handles actual commanding the tanks to fire all their guns. 
 * 
 */

package ca.cmpt213.as2;

import java.util.ArrayList;

public class Cpu {

	public void startTurn(){
		fireAllGuns();
	}
	
	private void fireAllGuns(){
		ArrayList<Tank> tanks = GameSystem.battlefield.getTankList();
		int totalFiringDamage = 0;
		for (Tank tank : tanks){
			totalFiringDamage += tank.getDamage();
			System.out.println("You were shot for: " + tank.getDamage());
		}
		
		int currentStructuralStrength = GameSystem.fortress.getStructuralStrength();
		GameSystem.fortress.setStructuralStrength(currentStructuralStrength - totalFiringDamage);
	}
}
