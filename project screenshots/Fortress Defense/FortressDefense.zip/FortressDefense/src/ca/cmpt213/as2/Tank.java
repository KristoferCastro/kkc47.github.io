/*
 * This class handles all tank behaviors and actions.  This includes tank cells manipulation.
 * Retrieving a tank's coordinates if it were to be placed onto board.  Managing it's own
 * damange power.
 * 
 */

package ca.cmpt213.as2;

import java.util.ArrayList;

public class Tank {

	
	private int tankID;
	private int damage;
	private Shape shape;
	private ArrayList<TankCell> tankCells;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public Tank(int tankID){
		this.shape = new Shape();
		this.tankID = tankID;
	}
	
	// get's the coordinates relative to the pivot and direction of the tank
	public ArrayList<Coordinate> getTankCoordinates(Coordinate pivot, String direction){
		ArrayList<Coordinate> tankCoordinates = new ArrayList<Coordinate>();
		Coordinate c1;
		Coordinate c2;
		Coordinate c3;
		Coordinate c4;
		char shape = this.shape.getShape();
		if ( shape == 'I' ){
			if( direction.equals("up") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate(pivot.getRow(),pivot.getColumn() - 1);
				c3 = new Coordinate(pivot.getRow(),pivot.getColumn() - 2);
				c4 = new Coordinate(pivot.getRow(),pivot.getColumn() - 3);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("down") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate(pivot.getRow(),pivot.getColumn() + 1);
				c3 = new Coordinate(pivot.getRow(),pivot.getColumn() + 2);
				c4 = new Coordinate(pivot.getRow(),pivot.getColumn() + 3);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("left") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() - 2),pivot.getColumn());
				c4 = new Coordinate((char) (pivot.getRow() - 3),pivot.getColumn());
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("right") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() + 2),pivot.getColumn());
				c4 = new Coordinate((char) (pivot.getRow() + 3),pivot.getColumn());
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}
		}else if (shape == 'T'){
			if( direction.equals("up") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() - 1);
				c3 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() - 2);
				c4 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn() - 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("down") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() + 1);
				c3 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn() + 1);
				c4 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() + 2 );
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("left") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() - 2),pivot.getColumn());
				c4 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn() - 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
				
			}else if ( direction.equals("right") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() + 2),pivot.getColumn());
				c4 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn() + 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}	
		}else if (shape == 'Z'){
			if( direction.equals("up") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() - 1);
				c3 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn() - 1);
				c4 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn() - 2);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("down") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() + 1);
				c3 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn() + 1);
				c4 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn() + 2);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
				
			}else if ( direction.equals("left") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn() + 1);
				c4 = new Coordinate((char) (pivot.getRow() - 2),pivot.getColumn() + 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
				
			}else if ( direction.equals("right") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn() + 1);
				c4 = new Coordinate((char) (pivot.getRow() + 2),pivot.getColumn() + 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
				
			}
		}else if (shape == 'O'){
			if( direction.equals("up") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() - 1);
				c4 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn() - 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("down") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() + 1);
				c4 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn() + 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("left") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn() + 1);
				c4 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() + 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
				
			}else if ( direction.equals("right") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn() - 1);
				c4 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() - 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}	
		}else if ( shape == 'L' ){
			if( direction.equals("up") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() - 1);
				c3 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() - 2);
				c4 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn() - 2);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("down") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() + 1);
				c3 = new Coordinate((char) (pivot.getRow()),pivot.getColumn() + 2);
				c4 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn() + 2);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}else if ( direction.equals("left") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() - 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() - 2),pivot.getColumn());
				c4 = new Coordinate((char) (pivot.getRow() - 2),pivot.getColumn() + 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
				
			}else if ( direction.equals("right") ){
				c1 = new Coordinate(pivot.getRow(),pivot.getColumn());
				c2 = new Coordinate((char) (pivot.getRow() + 1),pivot.getColumn());
				c3 = new Coordinate((char) (pivot.getRow() + 2),pivot.getColumn());
				c4 = new Coordinate((char) (pivot.getRow() + 2),pivot.getColumn() - 1);
				tankCoordinates.add(c1);
				tankCoordinates.add(c2);
				tankCoordinates.add(c3);
				tankCoordinates.add(c4);
			}	
		}
		return tankCoordinates;
	}

	public Shape getShape(){
		return this.shape;
	}
	
	public int getID(){
		return this.tankID;
	}
	
	public int getDamage(){
		int result = 0;
		int damagedTankCells = numberDamagedTankCells();
		
		if (damagedTankCells == 0){
			result = 20;
		}else if(damagedTankCells == 1){
			result = 5;
		}else if(damagedTankCells == 2){
			result = 2;
		}else if(damagedTankCells == 3){
			result = 1;
		}
		return result;
	}
	
	private int numberDamagedTankCells(){
		int result = 0;
		for(TankCell tc : tankCells){
			if( tc.isDamaged() == true)
				result++;
		}
		return result;
	}
	
	public boolean isDestroyed(){
		if (numberDamagedTankCells() == 4){
			return true;
		}
		return false;
	}
	
	public void setTankCells(ArrayList<Coordinate> tankCoordinates){
		tankCells = new ArrayList<TankCell>();
		for(Coordinate c : tankCoordinates){
			TankCell tc = new TankCell(c);
			this.tankCells.add(tc);
		}
	}
	
	public TankCell getTankCell(Coordinate c){
		TankCell output = null;
		char row = c.getRow();
		int column = c.getColumn()-1;
		for(TankCell tc : tankCells){
			//System.out.println("Tank Cell: " + tc.coordinate.getRow() + tc.coordinate.getColumn());
			if(row == tc.coordinate.getRow() && column == tc.coordinate.getColumn())
				output = tc;
		}	
		GameSystem.battlefield.showSystemBoard();
		return output;
	}
}
