/*
 * This class is just a structure that characterizes a shape and is able to generate a random shape.
 * 
 */

package ca.cmpt213.as2;

import java.util.ArrayList;
import java.util.Random;

public class Shape {

	private char shape;
	
	public static void main(String[] args) {
		Shape shape1 = new Shape();
		Shape shape2 = new Shape();
		
		System.out.println(shape1.shape);
		System.out.println(shape2.shape);
	}
	
	public Shape(){
		this.shape = generateShape();
	}
	
	private char generateShape(){
		Random randomGenerator = new Random();
		char[] shapes = {'I','T','Z','O','L'};
		int randomIndex = randomGenerator.nextInt(5);
		this.shape = shapes[randomIndex];
		return this.shape;
	}
	
	public char getShape(){
		return shape;
	}
	
	@Override
	public String toString(){
		return "" + this.shape;
	}
}
