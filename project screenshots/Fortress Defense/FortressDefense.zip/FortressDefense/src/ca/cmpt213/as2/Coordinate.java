/*
 * This class essentially acts as a structure used throughout the program.  It holds
 * a row and column.
 * 
 */

package ca.cmpt213.as2;

public class Coordinate {

	private char row;
	private int column;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public Coordinate(char row, int column){
		this.row = row;
		this.column = column;
	}

	public char getRow(){
		return row;
	}
	
	public int getColumn(){
		return column;
	}
	
	public static int getRowInt(char row){
		return row-'A';
	}
}
