/*
 * This class deals with all battlefield related behaviors and actions.  Key methods are keeping track of
 * system and users view of the battlefield, managing tanks in the field (generation, placement)
 * 
 */

package ca.cmpt213.as2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.TreeMap;

public class BattleField {

	private int numberOfTanks;
	public int[][] systemBattleField;
	private char[][] userBattleField;
	private HashMap<Integer, Tank> tanks;
	private ArrayList<Coordinate> unoccupiedCells;
	
	// Testing the functions, remove this main method later
	public static void main(String[] args) {
		BattleField bf = new BattleField(10,10, 5);
		bf.showUserBoard();
		bf.showSystemBoard();
		
		// testing markCell method
		
		while (true){
		    Scanner in = new Scanner(System.in);
		    String location;
		    System.out.println("enter a location: ");
		    location = in.nextLine();
		    
		    char row = location.charAt(0);
		    int column = location.charAt(1) - '0';
		    Coordinate c = new Coordinate(row, column);
		    bf.markCells(c);
			bf.showUserBoard();
		}    
	}

	public BattleField(int rowSize, int colSize, int numberOfTanks){
		systemBattleField = new int[rowSize][colSize];
		userBattleField = new char[rowSize][colSize];
		unoccupiedCells = new ArrayList<Coordinate>();
		tanks = new HashMap<Integer, Tank>();
		this.numberOfTanks = numberOfTanks;
		
		// initially adds all cells represented as coordinates in the field as unoccupied cells
		for(int row = 0; row < rowSize; row++){
			for(int col = 0; col < colSize; col++){
				Coordinate coordinate = new Coordinate((char)(row + 'A'), col);
				userBattleField[row][col] = '~';
				unoccupiedCells.add(coordinate);
			}
		}
		generateTanks();
	}
	
	private void generateTanks(){
		
		// Let us create the tanks we will be trying to place in the board
		ArrayList<Tank> tanksToPlace = new ArrayList<Tank>();
		for (int i = 1; i <= numberOfTanks; i++){
			int tankID = i;
			Tank tank = new Tank(tankID);	
			tanksToPlace.add(tank);
			//System.out.println(tank.getShape());
		}	
		
		// Once we have all the tanks generated, let us try placing them on the board
		placeTanks(tanksToPlace);
	}
	
	public ArrayList<Tank> getTankList(){
		ArrayList<Tank> tankList = new ArrayList<Tank>();
		
		for(Tank tank : tanks.values()){
			tankList.add(tank);
		}
		
		return tankList;
	}
	
	private void placeTanks(ArrayList<Tank> tanks){	
		shuffleUnOccupiedCells();	
		for(Tank tank : tanks){
			for(Coordinate cell : unoccupiedCells)
			{
				if (placeTank(tank, cell)){
					break;
				}
			}
		}
	}
	
	private boolean placeTank(Tank tank, Coordinate cell){
		boolean isPlaced = false;
		
		// set up the direction labels
		ArrayList<String> shapeDirections = new ArrayList<String>();
		shapeDirections.add("up");
		shapeDirections.add("down");
		shapeDirections.add("left");
		shapeDirections.add("right");
		
		// randomly pick a direction
		java.util.Collections.shuffle(shapeDirections);
		
		ArrayList<Coordinate> tankCoordinates;
		// find a direction that fits, if at all
		for(String direction : shapeDirections){
			tankCoordinates = tank.getTankCoordinates(cell, direction);
			
			// check if the tank fits with this direction
			if ( this.isFit(tankCoordinates) ){
				isPlaced = true;
				
				// update the user/system boards
				for(Coordinate coordinate : tankCoordinates){
					int row = Coordinate.getRowInt(coordinate.getRow());
					int column = coordinate.getColumn();
					
					// lets mark the system battle field with the tank ID
					systemBattleField[row][column] = tank.getID();
					
					// make sure we remove the cells we've occupied
					unoccupiedCells.remove(coordinate);
				}
				
				// lets add it into our hashmap of on-board tanks
				tank.setTankCells(tankCoordinates);
				tanks.put(tank.getID(), tank);
				break;
			}
		}
		return isPlaced;
	}
	
	private boolean isFit(ArrayList<Coordinate> tankCoordinates){
		// if we can find one occupied cell already, we return false
		for(Coordinate coordinate : tankCoordinates){
			int row = Coordinate.getRowInt(coordinate.getRow());
			int column = coordinate.getColumn();
			
			//check for out of bounds or if a tank is already on the cell
			if (row < 0 || row >= systemBattleField.length || 
					column < 0 || column >= systemBattleField.length
					|| systemBattleField[row][column] > 0){
				return false;
			}
		}
		return true;
	}
	
	public int numberOfTanksDestroyed(){
		int result = 0;
		
		for(Tank tank : tanks.values()){
			if ( tank.isDestroyed() ){
				result++;
			}
		}
		return result;
	}
	
	private void shuffleUnOccupiedCells(){
		java.util.Collections.shuffle(this.unoccupiedCells);
	}
	
	public void markCells(Coordinate coordinate){
		int row = Coordinate.getRowInt(coordinate.getRow());
		int column = coordinate.getColumn();
		int tankID = systemBattleField[row][column-1];
		
		if (tankID > 0){
			userBattleField[row][column-1] = 'X'; // we hit a tank
			System.out.println("---> HIT!");
			//System.out.println("coordinate: " + coordinate.getRow() + coordinate.getColumn());
			updateDamagedTank(tankID, coordinate);
		}else{
			userBattleField[row][column-1] = '.'; // we missed a tank
			System.out.println("---> MISS!");
		}
	}
	
	private void updateDamagedTank(int tankID, Coordinate c){
		Tank tank = tanks.get(tankID);
		TankCell tc = tank.getTankCell(c);
		tc.setIsDamaged(true);
	}
	
	public void showUserBoard(){
		System.out.println("Game Board (User):");
		int rowLength = userBattleField.length;
		int colLength = userBattleField.length;
		System.out.print("\t  ");
		for(int col = 1; col <= colLength; col++){
			System.out.print(String.format("%3s",col));
		}
		System.out.println("\n\t---------------------------------");
		for(int row = 0; row < rowLength; row++){
			System.out.print("\t" + (char)(row + 'A') + "|");
			for(int col = 0; col < colLength; col++){
				String result = String.format("%3s",userBattleField[row][col]);
				System.out.print(result);
			}
			System.out.println();
		}
	}
	
	public void showSystemBoard(){
		System.out.println("Game Board (System):");
		int rowLength = systemBattleField.length;
		int colLength = systemBattleField.length;
		System.out.print("\t  ");
		for(int col = 1; col <= colLength; col++){
			System.out.print(String.format("%3s",col));
		}
		System.out.println("\n\t---------------------------------");
		for(int row = 0; row < rowLength; row++){
			System.out.print("\t" + (char)(row + 'A') + "|");
			for(int col = 0; col < colLength; col++){
				String result = String.format("%3s",systemBattleField[row][col]);
				System.out.print(result);
			}
			System.out.println();
		} 
	}
	
	public void showCombinedBoard(){
		
		int rowLength = userBattleField.length;
		int colLength = userBattleField.length;
		char[][] combinedBoard = new char[rowLength][colLength];
		
		for(int row = 0; row < rowLength; row++){
			for(int col = 0; col < colLength; col++){
				if (userBattleField[row][col] == '.'){
					combinedBoard[row][col] = '.';
				}else if (userBattleField[row][col] == '~'){
					if (systemBattleField[row][col] == 0){
						combinedBoard[row][col] = '~';
					}else{
						combinedBoard[row][col] = 'X';
					}
				}
			}
		}
		
		System.out.println("Game Board (Combined):");
		System.out.print("\t  ");
		for(int col = 1; col <= colLength; col++){
			System.out.print(String.format("%3s",col));
		}
		System.out.println("\n\t---------------------------------");
		for(int row = 0; row < rowLength; row++){
			System.out.print("\t" + (char)(row + 'A') + "|");
			for(int col = 0; col < colLength; col++){
				String result = String.format("%3s",combinedBoard[row][col]);
				System.out.print(result);			
			}
			System.out.println();
		}
	}
}
